#!/bin/bash

# Description: Build your library, or meta pkg into a PKGBUILD. This will compress your files into a tar.gz, generate the PKGBUILD, .install, and CHANGELOG.md files into the `pkgbuild/pkgname` dir. It searches for a `bin/pkgname` file, and if it does not exist it's assumed to be a meta package and will fail at compressing.
#
# Args:
#   $1: Name of bin command
#   ${@:2}: Subtitle for command (optional)
#
# Returns:
#    0 | 1: status "${FUNCNAME} ${rootDir}/${f}..."
#    2: status "${dir} does not exist...$(CODE 2)"
#
# Examples:
#    cmdFile binCmd "My awesome subtitle"
#      : Output the bin file to the terminal. Includes a subtitle.
#    cmdFile binCmd > /path/to/bin/binCmd
#      : Output the bin file to your bin directory. It will be executable.
pkgbuild(){
  pkgname=${@}
  pkgbuildDir="${rootDir}/pkgbuild/${pkgname}"

  [[ $# -eq 0 ]] && printf "Syntax: ${FUNCNAME} <pkgname>\n" && return 2
  [[ ! -d ${pkgbuildDir} ]] && mkdir -p ${pkgbuildDir}
  [[ -f ${baseDir}/bin/${pkgname} ]] && pkgver=$(${baseDir}/bin/${pkgname} -v) && cd ${baseDir%source*} && tar -cf ${pkgbuildDir}/$pkgname-$pkgver.tar.gz ./source/{bin/${pkgname},${pkgname}/*} &> /dev/null
  status "Compressing ${pkgname}..."
  
  . ${baseDir}/pads/make.sh

  touch ${pkgbuildDir}/CHANGELOG.md
  pkgbuildFile ${pkgname} > ${pkgbuildDir}/PKGBUILD
  status "Making PKGBUILD..."
  installFile > ${pkgbuildDir}/.install
  status "Making .install..."
  #cp {PKGBUILD,.install,.SRCINFO} ${pkgbuildDir}
}

gitpkg(){
  # TODO: Use a git to compile/download source code to work on project and see docs, etc/
  echo $@
}

main(){
  devEnv
  pkgbuild ${pkgname}
}

usage(){
  cat << EOF
  Syntax: ${0##*/} -${mod} <arg> <opt>
  Usage:
    -p --pkgbuild <name>  Create a pkg that can be uploaded to an Arch Repo
    -h --help             Show Usage
  Ex: ${0##*/} -${mod}p padsutils
EOF
}

