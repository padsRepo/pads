#!/bin/bash

# Description: Output dir and file structures to a terminal before you commit.
#
# Args:
#   $1: List of directories. Can be array or text file.
#
# Returns:
#    0 | 1 | 2 | 127: status "${FUNCNAME} ${rootDir}/${d}..."
#
# Examples:
#    dryrun assets lib etc src share/{config,logs,utils}
#      : Create dir structure from an array separated by spaces. Using bash syntax for dirs is valid.
#    dryrun dirStructure.txt
#      : Create dir structure from a .txt file. The list must be separated by spaces or a new line.
#    dryrun dir/my-dir-structure.txt
#      : Create dir structure from a .txt file within a directory. The list must be separated by spaces or a new line.
dryrun(){
  dir=${@}
  profileDir="${baseDir}/padsutils/profiles/${dir}"

  [[ $# -eq 0 ]] && printf "Syntax: ${FUNCNAME[0]} <dir...>\n" && return 2
  if [[ ${dir} =~ ".t" ]]; then 
    [[ ! -f ${profileDir} ]] && status "${dir} does not exist...$(CODE 2)" && return 2
    dir=$(cat ${profileDir})
  fi
  
  for d in ${dir[@]}; do
    status "${FUNCNAME} ${rootDir}/${d}..."
  done
}

# Description: Create a project in the proper base directory, with the proper directory structure. This does not create any files, just directories
#
# Args:
#   $1: List of directories. Can be array or text file.
#
# Returns:
#    0 | 1: status "${FUNCNAME} ${rootDir}/${f}..."
#    2: status "${dir} does not exist...$(CODE 2)"
#
# Examples:
#    createDir assets lib etc src share/{config,logs,utils}
#      : Create dir structure from an array separated by spaces. Using bash syntax for dirs is valid.
#    createDir $HOME/devEnv devEnv.txt
#      : Create dir structure from a .txt file. The list must be separated by spaces or a new line.
#    createDir $HOME/devEnv/cmd shEnv.txt
#      : Create dir structure from a .txt file within a directory. The list must be separated by spaces or a new line.
createDir(){
  [[ $# -le 1 ]] && printf "Syntax: ${FUNCNAME[0]} <baseDir> <dirs...>\n" && return 2

  dir=${@:2}
  if [[ ${dir} =~ ".t" ]]; then 
    profileDir="$(padsutils -F --locateBinary $dir)"
    [[ ! -f ${profileDir} ]] && padsutils -Li "${dir} does not exist...\n" && return 2
    dir=$(cat ${profileDir})
  fi
  
  for d in ${dir[@]}; do
    padsutils -Li "${FUNCNAME} ${1}/${d}..."
    mkdir -p "${1}/${d}"
    padsutils -Ls 
  done
}

# Description: Create the files needed for each project
#
# Args:
#   $1: List of directories. Can be array or text file.
#
# Returns:
#    0 | 1: status "${FUNCNAME} ${rootDir}/${f}..."
#    2: status "${file} does not exist...$(CODE 2)"
#
# Examples:
#    createFile README.md CHANGELOG.md LICENSE docs/{architecture.md,index.md,designReport.md}
#      : Create file structure from an array separated by spaces. Using bash syntax for dirs is valid.
#    createFile fileStructure.txt
#      : Create file structure from a .txt file. The list must be separated by spaces or a new line.
#    createFile file/my-file-structure.txt
#      : Create file structure from a .txt file within a directory. The list must be separated by spaces or a new line.
createFile(){
  [[ $# -le 1 ]] && printf "Syntax: ${FUNCNAME[0]} <baseDir> <dirs...>\n" && return 2

  files=${@:2}
  if [[ ${files} =~ ".t" ]]; then 
    profileDir="$(padsutils -F --locateBinary $files)"
    [[ ! -f ${profileDir} ]] && padsutils -Li "${files} does not exist...\n" && return 2
    files=$(cat ${profileDir})
  fi
  
  for f in ${files[@]}; do
    padsutils -Li "${FUNCNAME} ${1}/${f}..."
    touch "${1}/${f}"
    padsutils -Ls 
  done
}

# Description: Build the architecture for a new env. i.e. a dev env, a repo, a git, etc.
#
# Args:
#   $1: List of directories. Can be array or text file.
#   $2: List of files. Can be array or text file.
#
# Returns:
#    0 | 1: status "${FUNCNAME} ${rootDir}/${f}..."
#    2: status "${dir} does not exist...$(CODE 2)"
#
# Examples:
#    architecture dev/{assets,lib,etc,src,share/{config,logs,utils,docs}} dev/{README.md,CHANGELOG.md,LICENSE,dev/docs/{executiveSummary.md,designReport.md,researchReport.md}}
#      : Create dir and file structure from an array separated by spaces. The first parameter is dir, the second parameter is files. Using bash syntax for dirs is valid.
#    architecture dirStructure.txt fileStructure.txt
#      : Create dir structure from a .txt file. The first parameter is dir, the second parameter is files. The list must be separated by spaces or a new line.
#    architecture dir/my-dir-structure.txt file/my-file-structure.txt
#      : Create dir structure from a .txt file within a directory. The first parameter is dir, the second parameter is files. The list must be separated by spaces or a new line.
architecture(){
  dir=${1}
  file=${2}
  profileDir="${baseDir}/padsutils/profiles/"
  
  [[ $# -le 1 ]] && printf "Syntax: ${FUNCNAME[0]} <dir.txt> <file.txt>\n" && return 2
  if [[ ${dir} =~ ".t" ]]; then
    [[ ! -f ${baseDir}/padsutils/profiles/${dir} ]] && status "${dir} does not exist...$(CODE 2)" && return 2 || dir=$(cat ${profileDir}/${dir})
    [[ ! -f ${baseDir}/padsutils/profiles/${file} ]] && status "${file} does not exist...$(CODE 2)" && return 2 || file=$(cat ${profileDir}/${file})
  fi
  
  createDir ${dir}
  createFile ${file}
}

usage(){
  cat << EOF
  Syntax: ${0##*/} -${mod} <arg> <opt>
  Usage:
    -a --architecture <dirname.txt> <filename.txt>  Create dirs and files from text file.
    -d --directory <name...>                        Create project directory in ${rootDir}
    -f --file <name...>                             Create files for project
    -t --test <name>                                Test a dir or file structure before committing
    -h --help                                       Show Usage
  Ex: ${0##*/} -${mod}d asssets lib src etc share | ${0##*/} -${mod}d devDir.txt
EOF
}

